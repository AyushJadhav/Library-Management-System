import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class Transaction extends JFrame implements ActionListener
{
	JLabel bid,cno,idate;
	JTextField bid1,cno1,idate1;
	JButton add,save,display,exit1;
	Connection con;
	PreparedStatement pst;
	Statement st;
	ResultSet rs;
	Container d;
	public Transaction()
	{
		Font f1,f2;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library_management","root","root");
		    st=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		}
		catch(Exception ee) {}
		d=getContentPane();
		d.setLayout(null);
		d.setBackground(Color.LIGHT_GRAY);
		f1=new Font("Times New Roman",Font.BOLD,30);
		f2=new Font("Times New Roman",Font.BOLD,20);
		cno=new JLabel("Card Number : ");
		bid=new JLabel("Book ID : ");
		idate=new JLabel("Issue Date : ");
		cno1=new JTextField(30);
		bid1=new JTextField(30);
		idate1=new JTextField(30);
		add=new JButton("Add");
		save=new JButton("Save");
		display=new JButton("Display");
		exit1=new JButton("Exit");
		bid.setFont(f1); bid1.setFont(f1);
		cno.setFont(f1); cno1.setFont(f1);
		idate.setFont(f1); idate1.setFont(f1);
		add.setFont(f2);	save.setFont(f2); exit1.setFont(f2); display.setFont(f2);
		bid.setBounds(100, 100, 300, 50);
		cno.setBounds(100, 200, 300, 50);
		idate.setBounds(100, 300, 300, 50);
		bid1.setBounds(425, 100, 300, 50);
		cno1.setBounds(425, 200, 300, 50);
		idate1.setBounds(425, 300, 300, 50);
		add.setBounds(100, 450, 100, 50);
		save.setBounds(275, 450, 100, 50);
		display.setBounds(450, 	450, 100, 50);
		exit1.setBounds(625, 450, 100, 50);
		add.setEnabled(false);
		d.add(bid); d.add(bid1);
		d.add(cno); d.add(cno1);
		d.add(idate); d.add(idate1);
		d.add(add);	d.add(save); d.add(display); d.add(exit1);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setTitle("Member Master");
	    setSize(825,725);
	    setVisible(true);
	    add.addActionListener(this);
	    save.addActionListener(this);
	    display.addActionListener(this);
	    exit1.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e)
	{
		int k;
		boolean flag;
		try
		{
			if(e.getSource()==save)
			{
				pst=con.prepareStatement("insert into transaction values (?,?,?)");
				pst.setInt(1, Integer.parseInt(bid1.getText()));
				pst.setInt(2, Integer.parseInt(cno1.getText()));
				pst.setDate(3, Date.valueOf(idate1.getText()));
				k=pst.executeUpdate();
				JOptionPane.showMessageDialog(null,"Record Saved","My Project",1);
				bid1.setText(""); cno1.setText(""); idate1.setText("");
			}
			if(e.getSource()==display)
			{
				flag=false;
				rs=st.executeQuery("select * from transaction");
				while(rs.next())
				{
					if(Integer.parseInt(bid1.getText())==rs.getInt(1))
					{
						bid1.setText(rs.getInt(1)+"");
						cno1.setText(rs.getInt(2)+"");
						idate1.setText(rs.getDate(3)+"");
						flag=true;
						break;
					}
				}
				if(flag==false)
					JOptionPane.showMessageDialog(null,"Record Not Found","My Project",2);
			}
			if(e.getSource()==exit1)
				setVisible(false);
		}
		catch(Exception ee) {}
	}
	/*public static void main(String[] args)
	{
		new Transaction();
	}*/
}
