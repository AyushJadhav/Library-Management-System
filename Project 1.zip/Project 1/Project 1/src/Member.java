import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class Member extends JFrame implements ActionListener
{
	JLabel cno,name,address,pno;
	JTextField cno1,name1,address1,pno1;
	JButton add,save,delete,display,exit1;
	Connection con;
	PreparedStatement pst;
	Statement st;
	ResultSet rs;
	Container d;
	public Member()
	{
		Font f1,f2;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library_management","root","root");
		    st=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		}
		catch(Exception ee) {}
		d=getContentPane();
		d.setLayout(null);
		d.setBackground(Color.LIGHT_GRAY);
		f1=new Font("Times New Roman",Font.BOLD,30);
		f2=new Font("Times New Roman",Font.BOLD,20);
		cno=new JLabel("Card Number : ");
		name=new JLabel("Member Name : ");
		address=new JLabel("Address : ");
		pno=new JLabel("Phone Number : ");
		cno1=new JTextField(30);
		name1=new JTextField(30);
		address1=new JTextField(30);
		pno1=new JTextField(30);
		add=new JButton("Add");
		save=new JButton("Save");
		delete=new JButton("Delete");
		display=new JButton("Display");
		exit1=new JButton("Exit");
		cno.setFont(f1);	cno1.setFont(f1);
		name.setFont(f1);	name1.setFont(f1);
		address.setFont(f1);	address1.setFont(f1);
		pno.setFont(f1);	pno1.setFont(f1);
		add.setFont(f2);	save.setFont(f2); delete.setFont(f2); display.setFont(f2); exit1.setFont(f2);
		cno.setBounds(100, 100, 300, 50);	name.setBounds(100, 180, 300, 50);
		address.setBounds(100, 260, 300, 50);	pno.setBounds(100, 340, 300, 50);
		cno1.setBounds(425, 100, 300, 50);	name1.setBounds(425, 180, 300, 50);
		address1.setBounds(425, 260, 300, 50);	pno1.setBounds(425, 340, 300, 50);
		add.setBounds(100, 450, 100, 50);	save.setBounds(275, 450, 100, 50);
		delete.setBounds(450, 	450, 100, 50);	display.setBounds(625, 450, 100, 50);
		exit1.setBounds(100, 520, 100, 50);
		cno1.setEnabled(false);
		d.add(cno);	d.add(cno1);
		d.add(name);	d.add(name1);
		d.add(address);	d.add(address1);
		d.add(pno);	d.add(pno1);
		d.add(add);	d.add(save); d.add(delete); d.add(display); d.add(exit1);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setTitle("Member Master");
	    setSize(825,725);
	    setVisible(true);
	    add.addActionListener(this);
	    save.addActionListener(this);
	    delete.addActionListener(this);
	    display.addActionListener(this);
	    exit1.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e)
	{
		int k,count;
		boolean flag;
		try
		{
			if(e.getSource()==add)
			{
				name1.setText("");
				address1.setText("");
				pno1.setText("");
				count=0;
				rs=st.executeQuery("select card_no from member_master");
				while(rs.next())
				{
					count=rs.getInt(1);
				}
				if(count==0)
					cno1.setText("1801");
				else
					cno1.setText(""+(count+1));
			}
			if(e.getSource()==save)
			{
				pst=con.prepareStatement("insert into member_master values (?,?,?,?)");
				pst.setInt(1, Integer.parseInt(cno1.getText()));
				pst.setString(2, name1.getText());
				pst.setString(3, address1.getText());
				pst.setString(4, pno1.getText());
				k=pst.executeUpdate();
				JOptionPane.showMessageDialog(null,"Record Saved","My Project",1);
			}
			if(e.getSource()==delete)
			{
				cno1.setText("");
				name1.setText("");
				address1.setText("");
				pno1.setText("");
				int num=Integer.parseInt(JOptionPane.showInputDialog("Please Enter Card Number to Delete Record"));
				pst=con.prepareStatement("delete from member_master where card_no=?");
				pst.setInt(1, num);
				k=pst.executeUpdate();
				JOptionPane.showMessageDialog(null,"Record Deleted","My Project",1);
			}
			if(e.getSource()==display)
			{
				flag=false;
				cno1.setText("");
				name1.setText("");
				address1.setText("");
				pno1.setText("");
				int num=Integer.parseInt(JOptionPane.showInputDialog("Please Enter Card Number to Display Record"));
				rs=st.executeQuery("select * from member_master");
				while(rs.next())
				{
					if(num==rs.getInt(1))
					{
						cno1.setText(rs.getInt(1)+"");
						name1.setText(rs.getString(2));
						address1.setText(rs.getString(3));
						pno1.setText(rs.getString(4));
						flag=true;
						break;
					}
				}
				if(flag==false)
					JOptionPane.showMessageDialog(null,"Record Not Found","My Project",2);
			}
			if(e.getSource()==exit1)
				setVisible(false);
		}
		catch(Exception ee) {}
	}
	/*public static void main(String[] args)
	{
		new Member();
	}*/
}
