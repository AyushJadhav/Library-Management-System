import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.imageio.*;

public class Main extends JFrame implements ActionListener
{
	JButton b1,b2,b3,b4;
	Connection con;
	PreparedStatement pst;
	Statement st;
	ResultSet rs;
	Container d;
	public Main()
	{
		Font f1;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library_management","root","root");
		    st=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		}
		catch(Exception ee) {}
		d=getContentPane();
		d.setLayout(null);
		d.setBackground(Color.LIGHT_GRAY);
		f1=new Font("Times New Roman",Font.BOLD,40);
		b1=new JButton("Book Master");
		b2=new JButton("Member Master");
		b3=new JButton("Issue Book");
		b4=new JButton("Return Entry");
		b1.setBounds(100, 75, 500, 100);
		b2.setBounds(100, 225, 500, 100);
		b3.setBounds(100, 375, 500, 100);
		b4.setBounds(100, 525, 500, 100);
		b1.setFont(f1); b2.setFont(f1); b3.setFont(f1); b4.setFont(f1);
		d.add(b1); d.add(b2); d.add(b3); d.add(b4);
		setIconImage(Toolkit.getDefaultToolkit().getImage("‪D:\\images.jpeg"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setTitle("Main");
	    setSize(725,725);
	    setVisible(true);
	    b1.addActionListener(this);
	    b2.addActionListener(this);
	    b3.addActionListener(this);
	    b4.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==b1)
			new Book();
		if(e.getSource()==b2)
			new Member();
		if(e.getSource()==b3)
			new Transaction();
		if(e.getSource()==b4)
			new ReturnEntry();
	}
	public static void main(String[] args)
	{
		new Main();
	}
}
