import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class ReturnEntry extends JFrame implements ActionListener
{
	JLabel book_id,borrower_id,idate,rdate;
	JTextField book_id1,borrower_id1,idate1,rdate1;
	JButton retrieve,save,exit1;
	Connection con;
	PreparedStatement pst;
	Statement st;
	ResultSet rs;
	Container d;
	public ReturnEntry()
	{
		Font f1,f2;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library_management","root","root");
		    st=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		}
		catch(Exception ee) {}
		d=getContentPane();
		d.setLayout(null);
		d.setBackground(Color.LIGHT_GRAY);
		f1=new Font("Times New Roman",Font.BOLD,30);
		f2=new Font("Times New Roman",Font.BOLD,20);
		book_id=new JLabel("Book ID : ");
		//book_title=new JLabel("Book Title : ");
		borrower_id=new JLabel("Borrower ID : ");
		idate=new JLabel("Issue Date : ");
		rdate=new JLabel("Return Date : ");
		book_id1=new JTextField(30);
		//book_title1=new JTextField(30);
		borrower_id1=new JTextField(30);
		idate1=new JTextField(30);
		rdate1=new JTextField(30);
		retrieve=new JButton("Retrieve");
		save=new JButton("Save");
		exit1=new JButton("Exit");
		book_id.setFont(f1);  borrower_id.setFont(f1);
		idate.setFont(f1); rdate.setFont(f1);
		book_id1.setFont(f1);  borrower_id1.setFont(f1);
		idate1.setFont(f1); rdate1.setFont(f1);
		retrieve.setFont(f2); save.setFont(f2); exit1.setFont(f2);
		borrower_id.setBounds(100, 100, 300, 50);
		book_id.setBounds(100, 160, 300, 50);
		idate.setBounds(100, 220, 300, 50);
		rdate.setBounds(100, 280, 300, 50);
		//rdate.setBounds(100, 340, 300, 50);
		borrower_id1.setBounds(425, 100, 300, 50);
		book_id1.setBounds(425, 160, 300, 50);
		idate1.setBounds(425, 220, 300, 50);
		rdate1.setBounds(425, 280, 300, 50);
		//rdate1.setBounds(425, 340, 300, 50);
		retrieve.setBounds(275, 450, 110, 50);
		save.setBounds(450, 450, 100, 50);
		exit1.setBounds(625, 450, 100, 50);
		d.add(borrower_id); d.add(borrower_id1);
		d.add(book_id); d.add(book_id1);
		//d.add(book_title); d.add(book_title1);
		d.add(idate); d.add(idate1);
		d.add(rdate); d.add(rdate1);
		d.add(retrieve); d.add(save); d.add(exit1);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setTitle("Return Entry");
	    setSize(840,725);
	    setVisible(true);
	    retrieve.addActionListener(this);
	    save.addActionListener(this);
	    exit1.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e)
	{
		int k;
		boolean flag;
		try
		{
			if(e.getSource()==retrieve)
			{
				flag=false;
				rs=st.executeQuery("select * from transaction");
				while(rs.next())
				{
					if(Integer.parseInt(borrower_id.getText())==rs.getInt(2))
					{
						book_id.setText(rs.getInt(1)+"");
						borrower_id.setText(rs.getInt(2)+"");
						idate.setText(rs.getDate(3)+"");
						flag=true;
						break;
					}
				}
				if(flag==false)
					JOptionPane.showMessageDialog(null,"Record Not Found","My Project",2);
			}
			if(e.getSource()==save)
			{
				pst=con.prepareStatement("insert into return_entry values (?,?,?,?)");
				pst.setInt(1, Integer.parseInt(borrower_id1.getText()));
				pst.setInt(2, Integer.parseInt(book_id1.getText()));
				pst.setDate(3, Date.valueOf(idate1.getText()));
				pst.setDate(4, Date.valueOf(rdate1.getText()));
				k=pst.executeUpdate();
				JOptionPane.showMessageDialog(null,"Record Saved","My Project",1);
				PreparedStatement pst1=con.prepareStatement("delete from transaction where card_no=?");
				pst1.setInt(1, Integer.parseInt(borrower_id1.getText()));
				int l=pst1.executeUpdate();
			}
			if(e.getSource()==exit1)
				setVisible(false);
		}
		catch(Exception ee) {}
	}
}
