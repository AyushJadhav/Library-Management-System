import java.awt.event.*;
import java.awt.*;
import java.sql.*;
import javax.swing.*;

public class Book extends JFrame implements ActionListener
{
	JLabel bid,btitle,author,pub,price;
	JTextField bid1,btitle1,author1,pub1,price1;
	JButton add,save,delete,display,exit1;
	Connection con;
	PreparedStatement pst;
	Statement st;
	ResultSet rs;
	Container d;
	public Book()
	{
		Font f1,f2;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
		    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/library_management","root","root");
		    st=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_UPDATABLE);
		    //System.out.println("1");
		}
		catch(Exception ee) {/*System.out.println("2");*/}
		d=getContentPane();
		d.setLayout(null);
		d.setBackground(Color.LIGHT_GRAY);
		f1=new Font("Times New Roman",Font.BOLD,30);
		f2=new Font("Times New Roman",Font.BOLD,20);
		bid=new JLabel("Book ID : ");
		btitle=new JLabel("Book Title : ");
		author=new JLabel("Author : ");
		pub=new JLabel("Publication : ");
		price=new JLabel("Price : ");
		bid1=new JTextField(30);
		btitle1=new JTextField(30);
		author1=new JTextField(30);
		pub1=new JTextField(30);
		price1=new JTextField(30);
		add=new JButton("Add");
		save=new JButton("Save");
		delete=new JButton("Delete");
		display=new JButton("Display");
		exit1=new JButton("Exit");
		bid.setFont(f1);
		btitle.setFont(f1);
		author.setFont(f1);
		pub.setFont(f1);
		price.setFont(f1);
		bid1.setFont(f1);
		btitle1.setFont(f1);
		author1.setFont(f1);
		pub1.setFont(f1);
		price1.setFont(f1);
		add.setFont(f2);
		save.setFont(f2);
		delete.setFont(f2);
		display.setFont(f2);
		exit1.setFont(f2);
		bid.setBounds(100, 100, 300, 50);
		btitle.setBounds(100, 160, 300, 50);
		author.setBounds(100, 220, 300, 50);
		pub.setBounds(100, 280, 300, 50);
		price.setBounds(100, 340, 300, 50);
		bid1.setBounds(425, 100, 300, 50);
		btitle1.setBounds(425, 160, 300, 50);
		author1.setBounds(425, 220, 300, 50);
		pub1.setBounds(425, 280, 300, 50);
		price1.setBounds(425, 340, 300, 50);
		add.setBounds(100, 450, 100, 50);
		save.setBounds(275, 450, 100, 50);
		delete.setBounds(450, 	450, 100, 50);
		display.setBounds(625, 450, 100, 50);
		exit1.setBounds(100, 520, 100, 50);
		bid1.setEnabled(false);
		d.add(bid);
		d.add(btitle);
		d.add(author);
		d.add(pub);
		d.add(price);
		d.add(bid1);
		d.add(btitle1);
		d.add(author1);
		d.add(pub1);
		d.add(price1);
		d.add(add);
		d.add(save);
		d.add(delete);
		d.add(display);
		d.add(exit1);
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setTitle("Book Master");
	    setSize(825,725);
	    setVisible(true);
	    add.addActionListener(this);
	    save.addActionListener(this);
	    delete.addActionListener(this);
	    display.addActionListener(this);
	    exit1.addActionListener(this);
	}
	public void actionPerformed(ActionEvent e)
	{
		int count,k;
		boolean flag;
		try
		{
			if(e.getSource()==add)
			{
				btitle1.setText("");
				author1.setText("");
				pub1.setText("");
				price1.setText("");
				count=0;
				rs=st.executeQuery("select book_id from book_master");
				while(rs.next())
				{
					count=rs.getInt(1);
				}
				if(count==0)
					bid1.setText("101");
				else
					bid1.setText(""+(count+1));
			}
			if(e.getSource()==save)
			{
				pst=con.prepareStatement("insert into book_master values (?,?,?,?,?)");
				pst.setInt(1, Integer.parseInt(bid1.getText()));
				pst.setString(2, btitle1.getText());
				pst.setString(3, author1.getText());
				pst.setString(4, pub1.getText());
				pst.setInt(5, Integer.parseInt(price1.getText()));
				k=pst.executeUpdate();
				JOptionPane.showMessageDialog(null,"Record Saved","My Project",1);
			}
			if(e.getSource()==delete)
			{
				int num=Integer.parseInt(JOptionPane.showInputDialog("Please Enter ID of Book to Delete Record"));
				pst=con.prepareStatement("delete from book_master where book_id=?");
				pst.setInt(1, num);
				k=pst.executeUpdate();
				JOptionPane.showMessageDialog(null,"Record Deleted","My Project",1);
			}
			if(e.getSource()==display)
			{
				flag=false;
				int num=Integer.parseInt(JOptionPane.showInputDialog("Please Enter ID of Book to Display Record"));
				rs=st.executeQuery("select * from book_master");
				while(rs.next())
				{
					if(num==rs.getInt(1))
					{
						bid1.setText(rs.getInt(1)+"");
						btitle1.setText(rs.getString(2));
						author1.setText(rs.getString(3));
						pub1.setText(rs.getString(4));
						price1.setText(rs.getInt(5)+"");
						flag=true;
						break;
					}
				}
				if(flag==false)
					JOptionPane.showMessageDialog(null,"Record Not Found","My Project",2);
			}
			if(e.getSource()==exit1)
				setVisible(false);
		}
		catch(Exception ee) {}
	}
	/*public static void main(String[] args)
	{
		new Book();
	}*/
}
